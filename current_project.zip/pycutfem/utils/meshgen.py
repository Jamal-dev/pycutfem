"""pycutfem.utils.meshgen
Mesh generators for quick tests.
"""
import numpy as np
from scipy.spatial import Delaunay

__all__ = ["delaunay_rectangle", "structured_quad"]

def delaunay_rectangle(length: float, height: float, nx: int = 10, ny: int = 10):
    x = np.linspace(0.0, length, nx)
    y = np.linspace(0.0, height, ny)
    X, Y = np.meshgrid(x, y)
    pts = np.column_stack([X.ravel(), Y.ravel()])
    tri = Delaunay(pts)
    elems = tri.simplices.copy()

    # make triangles CCW
    def signed_area(a, b, c):
        return (b[0]-a[0])*(c[1]-a[1]) - (b[1]-a[1])*(c[0]-a[0])
    for t in elems:
        a, b, c = pts[t]
        if signed_area(a, b, c) < 0:
            t[1], t[2] = t[2], t[1]
    return pts, elems

def structured_quad(Lx: float, Ly: float, nx: int = 10, ny: int = 10):
    """Return Q1 structured mesh over [0,Lx]×[0,Ly]."""
    x = np.linspace(0.0, Lx, nx+1)
    y = np.linspace(0.0, Ly, ny+1)
    X, Y = np.meshgrid(x, y)
    pts = np.column_stack([X.ravel(), Y.ravel()])
    quads = []
    def node_id(i,j):  # column, row
        return j*(nx+1) + i
    for j in range(ny):
        for i in range(nx):
            n0 = node_id(i,   j)
            n1 = node_id(i+1, j)
            n2 = node_id(i+1, j+1)
            n3 = node_id(i,   j+1)
            quads.append([n0, n1, n2, n3])
    return pts, np.array(quads, dtype=int)
