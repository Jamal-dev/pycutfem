"""pycutfem.core.mesh"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Tuple, List, Dict
import numpy as np

@dataclass(slots=True)
class Edge:
    id: int
    nodes: Tuple[int, int]
    left: int | None
    right: int | None
    normal: np.ndarray
    tag: str = ""

class Mesh:
    _EDGE_TABLE = {
        'tri': ((0,1),(1,2),(2,0)),
        'quad':((0,1),(1,2),(2,3),(3,0)),
    }
    def __init__(self, nodes: np.ndarray, elements: np.ndarray, *, element_type='tri'):
        self.nodes = np.ascontiguousarray(nodes, dtype=float)
        self.elements = np.ascontiguousarray(elements, dtype=int)
        self.element_type = element_type
        if self.nodes.ndim!=2 or self.nodes.shape[1]!=2:
            raise ValueError('nodes must be (N,2)')
        if self.elements.ndim!=2:
            raise ValueError('elements must be (M,k)')
        if element_type not in self._EDGE_TABLE:
            raise ValueError(element_type)
        self.edges: List[Edge] = []
        self._edge_dict: Dict[Tuple[int,int], int] = {}
        self._neighbors: List[List[int]] = [[] for _ in range(len(self.elements))]
        self.edge_tag = np.empty(0, dtype=object)
        self.elem_tag = np.zeros(len(self.elements), dtype=object)
        self._build_edges()
    # ------------------------
    def areas(self)->np.ndarray:
        if self.element_type=='tri':
            v0 = self.nodes[self.elements[:,0]]
            v1 = self.nodes[self.elements[:,1]]
            v2 = self.nodes[self.elements[:,2]]
            return 0.5*np.abs(np.cross(v1-v0, v2-v0))
        if self.element_type=='quad':
            v0=self.nodes[self.elements[:,0]]
            v1=self.nodes[self.elements[:,1]]
            v2=self.nodes[self.elements[:,2]]
            v3=self.nodes[self.elements[:,3]]
            return 0.5*np.abs(np.cross(v1-v0,v2-v0))+0.5*np.abs(np.cross(v2-v0,v3-v0))
        raise RuntimeError
    # ------------------------
    def edge(self,eid:int)->Edge:
        return self.edges[eid]
    def edge_dict(self):
        return self._edge_dict
    def neighbors(self):
        return self._neighbors
    # ------------------------
    def _build_edges(self):
        local_edges=self._EDGE_TABLE[self.element_type]
        inc: Dict[Tuple[int,int],List[int]]={}
        for eid,elem in enumerate(self.elements):
            for i,j in local_edges:
                e=tuple(sorted((elem[i],elem[j])))
                inc.setdefault(e,[]).append(eid)
        edges=[]
        edge_dict={}
        neighbors=[[] for _ in range(len(self.elements))]
        for idx,(nodes_pair, elems) in enumerate(inc.items()):
            left=elems[0]
            right=elems[1] if len(elems)==2 else None
            if right is not None:
                neighbors[left].append(right)
                neighbors[right].append(left)
            normal=self._compute_normal(nodes_pair,left)
            edges.append(Edge(id=idx,nodes=nodes_pair,left=left,right=right,normal=normal))
            edge_dict[nodes_pair]=idx
        self.edges=edges
        self._edge_dict=edge_dict
        self._neighbors=neighbors
        self.edge_tag=np.array(['']*len(edges),dtype=object)
    def _compute_normal(self,edge_nodes,left_elem):
        p0,p1=self.nodes[list(edge_nodes)]
        v=p1-p0
        n=np.array([v[1],-v[0]])
        n/=np.linalg.norm(n)
        centroid=self.nodes[self.elements[left_elem]].mean(axis=0)
        mid=0.5*(p0+p1)
        if np.dot(centroid-mid,n)>0:
            n*=-1.0
        return n
    def __repr__(self):
        return f'<Mesh n_nodes={len(self.nodes)} n_elems={len(self.elements)} n_edges={len(self.edges)}>'
