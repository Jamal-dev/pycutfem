"""pycutfem.assembly.load_vector"""
import numpy as np
from pycutfem.integration import volume
from pycutfem.fem.reference import get_reference
from pycutfem.fem import transform

def element_load(mesh, elem_id, f, order=4):
    n_loc = 3 if mesh.element_type=='tri' else 4
    Fe = np.zeros(n_loc)
    pts, wts = volume(mesh.element_type, order)
    ref = get_reference(mesh.element_type, 1)
    for xi_eta, w in zip(pts, wts):
        N = np.asarray(ref.shape(*xi_eta)).ravel()
        x = transform.x_mapping(mesh, elem_id, xi_eta)
        J = transform.jacobian(mesh, elem_id, xi_eta)
        detJ = np.linalg.det(J)
        Fe += w*detJ * N * f(*x)
    return Fe
