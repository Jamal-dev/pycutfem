"""pycutfem.assembly.local_assembler
Basic scalar stiffness for uncuts (Tri P1, Quad Q1).
"""
import numpy as np
from pycutfem.integration import volume
from pycutfem.fem.reference import get_reference
from pycutfem.fem import transform

def stiffness_matrix(mesh, elem_id, order=4):
    n_loc = 3 if mesh.element_type=='tri' else 4
    Ke = np.zeros((n_loc, n_loc))
    Fe = np.zeros(n_loc)

    pts, wts = volume(mesh.element_type, order)
    ref = get_reference(mesh.element_type, 1)
    for xi_eta, w in zip(pts, wts):
        dN = ref.grad(*xi_eta)               # (n_loc,2)
        J  = transform.jacobian(mesh, elem_id, xi_eta)
        invJ = np.linalg.inv(J)
        detJ = np.linalg.det(J)
        grad = dN @ invJ.T         # (n_loc,2)
        Ke += w*detJ * grad @ grad.T
    return Ke, Fe
