"""
pycutfem.fem.reference.tri_pn
Arbitrary order barycentric Lagrange basis on reference triangle.
"""
from functools import lru_cache
import sympy as sp
import numpy as np

@lru_cache(maxsize=None)
def tri_pn(n: int):
    xi, eta = sp.symbols("xi eta")
    L1, L2, L3 = 1 - xi - eta, xi, eta
    # All barycentric monomials i+j+k=n, k = n-i-j
    basis  = []
    dbasis = []
    for i in range(n + 1):
        for j in range(n + 1 - i):
            k = n - i - j
            phi = sp.binomial(n, i) * sp.binomial(n - i, j) * L1**k * L2**i * L3**j
            basis.append(phi)
            grad = sp.Matrix([sp.diff(phi, xi), sp.diff(phi, eta)])
            dbasis.append(grad)
    shape = sp.lambdify((xi, eta), sp.Matrix(basis), "numpy")
    grad  = sp.lambdify((xi, eta), sp.Matrix.hstack(*dbasis), "numpy")
    return shape, grad
