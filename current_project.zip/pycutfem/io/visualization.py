"""pycutfem.io.visualization"""
import numpy as np
from matplotlib.collections import LineCollection, PolyCollection
import matplotlib.pyplot as plt

_ELEM_FILL = {
    "inside": (0.4,0.6,1.0,0.25),   # light blue
    "cut":    (1.0,0.55,0.0,0.45),  # orange
}
_EDGE_COLOR = {"interface":"red", "ghost":"blue"}

def _edge_col(tag): return _EDGE_COLOR.get(tag, 'black')
def _elem_fill(tag): return _ELEM_FILL.get(tag, 'none')

def plot_mesh(mesh, *, level_set=None, edge_colors=True,
              show=True, ax=None, resolution=200):
    if ax is None:
        fig, ax = plt.subplots()

    # fill elems
    polys_by_color = {}
    if getattr(mesh, "elem_tag", None) is not None:
        for eid, tag in enumerate(mesh.elem_tag):
            face = _elem_fill(tag)
            if face == 'none':
                continue
            polys_by_color.setdefault(face, []).append(mesh.nodes[mesh.elements[eid]])
    for col, polys in polys_by_color.items():
        pc = PolyCollection(polys, facecolors=col, edgecolors='none', zorder=1)
        ax.add_collection(pc)

    # edges
    segs = [mesh.nodes[list(e.nodes)] for e in mesh.edges]
    cols = [_edge_col(mesh.edge_tag[e.id]) if edge_colors else 'black' for e in mesh.edges]
    lc = LineCollection(segs, colors=cols, linewidths=0.7, zorder=2)
    ax.add_collection(lc)

    # level-set contour
    if level_set is not None:
        xmin,ymin = mesh.nodes.min(axis=0)
        xmax,ymax = mesh.nodes.max(axis=0)
        gx,gy = np.meshgrid(np.linspace(xmin,xmax,resolution),
                            np.linspace(ymin,ymax,resolution))
        phi = np.apply_along_axis(level_set,1,np.column_stack([gx.ravel(),gy.ravel()]))
        phi = phi.reshape(gx.shape)
        ax.contour(gx,gy,phi,levels=[0.0],colors='green',linewidths=1.0,zorder=3)

    ax.set_aspect('equal','box')
    ax.set_xlim(mesh.nodes[:,0].min(), mesh.nodes[:,0].max())
    ax.set_ylim(mesh.nodes[:,1].min(), mesh.nodes[:,1].max())
    if show:
        plt.show()
    return ax
