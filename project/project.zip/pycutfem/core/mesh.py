import numpy as np
from dataclasses import dataclass
from typing import Tuple, List, Dict, Optional, Callable


from pycutfem.core.topology import Edge, Node, Element


class Mesh:
    """
    Manages mesh topology, including nodes, elements, and edges.

    This class builds the full connectivity graph from basic node and element
    definitions. It correctly identifies shared edges, assigns geometrically
    correct "left" and "right" elements, and computes outward-pointing normal
    vectors for each edge. It also includes methods for classifying elements
    and edges against a level-set function.
    """
    # Defines the local-corner indices that form each edge, in CCW order.
    _EDGE_TABLE = {
        'tri':  ((0, 1), (1, 2), (2, 0)),
        'quad': ((0, 1), (1, 2), (2, 3), (3, 0)),
    }

    def __init__(self,
                 nodes: List['Node'],
                 element_connectivity: np.ndarray,
                 edges_connectivity: np.ndarray,
                 elements_corner_nodes: np.ndarray,
                 *,
                 element_type: str = 'tri',
                 poly_order: int = 1):
        """
        Initializes the mesh and builds its topology.
        """
        self.edges_connectivity: np.ndarray = edges_connectivity
        self.element_type = element_type
        self.poly_order = poly_order
        self.nodes_list: List['Node'] = nodes
        self.nodes_x_y_pos = np.array([[n.x, n.y] for n in self.nodes_list], dtype=float)
        self.nodes = np.array([n.id for n in self.nodes_list])
        self.elements_connectivity: np.ndarray = element_connectivity
        self.corner_connectivity: np.ndarray = elements_corner_nodes
        self.elements_list: List['Element'] = []
        self.edges_list: List['Edge'] = []
        self._edge_dict: Dict[Tuple[int, int], 'Edge'] = {}
        self._neighbors: List[List[int]] = [[] for _ in range(len(self.elements_connectivity))]
        self._build_topology()

    def _build_topology(self):
        """
        Builds the full mesh topology: Elements, Edges, and Neighbors.
        """
        edge_defs = self._EDGE_TABLE[self.element_type]

        # Step 1: Create basic Element objects
        for eid, elem_nodes in enumerate(self.elements_connectivity):
            self.elements_list.append(Element(
                id=eid,
                element_type=self.element_type,
                poly_order=self.poly_order,
                nodes=tuple(elem_nodes),
                corner_nodes=tuple(self.corner_connectivity[eid]),
            ))

        # Step 2: Build map from each edge to the elements that share it
        edge_incidences: Dict[Tuple[int, int], List[int]] = {}
        for eid, corners in enumerate(self.corner_connectivity):
            for i in range(len(corners)):
                c1, c2 = int(corners[i]), int(corners[(i + 1) % len(corners)])
                key = tuple(sorted((c1, c2)))
                edge_incidences.setdefault(key, []).append(eid)

        # Step 3: Create unique Edge objects
        for edge_gid, ((n_min, n_max), shared_eids) in enumerate(edge_incidences.items()):
            left_eid = shared_eids[0]
            vA, vB = -1, -1
            left_elem_corners = self.corner_connectivity[left_eid]
            for i in range(len(left_elem_corners)):
                if {int(left_elem_corners[i]), int(left_elem_corners[(i + 1) % len(left_elem_corners)])} == {n_min, n_max}:
                    vA, vB = int(left_elem_corners[i]), int(left_elem_corners[(i + 1) % len(left_elem_corners)])
                    break
            right_eid = shared_eids[1] if len(shared_eids) > 1 else None
            normal_vec = self._compute_normal((vA, vB))
            edge_obj = Edge(gid=edge_gid, nodes=(vA, vB), left=left_eid, right=right_eid, normal=normal_vec)
            self.edges_list.append(edge_obj)
            self._edge_dict[(n_min, n_max)] = edge_obj
            if right_eid is not None:
                self._neighbors[left_eid].append(right_eid)
                self._neighbors[right_eid].append(left_eid)

        # Step 4: Populate each Element's list of its edge GIDs
        for elem in self.elements_list:
            local_edge_gids = [self._edge_dict[tuple(sorted((elem.corner_nodes[c1], elem.corner_nodes[c2])))].gid for c1, c2 in edge_defs]
            elem.edges = tuple(local_edge_gids)
        
        # Step 5: Populate neighbor info on each element
        for elem in self.elements_list:
            for local_edge_idx, edge_gid in enumerate(elem.edges):
                edge = self.edge(edge_gid)
                elem.neighbors[local_edge_idx] = edge.right if edge.left == elem.id else edge.left

    def _compute_normal(self, directed_edge_nodes: Tuple[int, int]) -> np.ndarray:
        """Computes an outward-pointing unit normal for a directed edge."""
        v_start, v_end = self.nodes_x_y_pos[directed_edge_nodes[0]], self.nodes_x_y_pos[directed_edge_nodes[1]]
        directed_vec = v_end - v_start
        raw_normal = np.array([directed_vec[1], -directed_vec[0]], dtype=float)
        length = np.linalg.norm(raw_normal)
        return raw_normal / length if length > 1e-14 else np.array([0.0, 0.0])

    # --- Classification Methods ---

    def _get_node_coords(self) -> np.ndarray:
        """Helper to get node coordinates as a NumPy array."""
        return self.nodes_x_y_pos
        
    def _phi_on_centroids(self, level_set) -> np.ndarray:
        """Compute φ at each element’s centroid."""
        node_coords = self._get_node_coords()
        # Note: Using corner_connectivity is correct for geometric centroid.
        conn = self.corner_connectivity
        corner_coords = node_coords[conn]
        centroids = corner_coords.mean(axis=1)
        
        # FIX: Use apply_along_axis to robustly call the level set function
        # on each centroid, one by one. This mimics the safe evaluation
        # from LevelSetFunction.evaluate_on_nodes and avoids issues with
        # __call__ methods that don't correctly handle batch inputs (N, 2).
        return np.apply_along_axis(level_set, 1, centroids)

    def classify_elements(self, level_set, tol=1e-12):
        """
        Classify each element as 'inside', 'outside', or 'cut'.
        Sets element.tag accordingly and returns indices for each class.
        """
        # Assumes level_set has a method evaluate_on_nodes(mesh)
        phi_nodes = level_set.evaluate_on_nodes(self)
        elem_phi_nodes = phi_nodes[self.corner_connectivity]
        phi_cent = self._phi_on_centroids(level_set)

        min_phi = np.minimum(elem_phi_nodes.min(axis=1), phi_cent)
        max_phi = np.maximum(elem_phi_nodes.max(axis=1), phi_cent)

        inside_mask = (max_phi < -tol)
        outside_mask = (min_phi > tol)
        
        inside_inds = np.where(inside_mask)[0]
        outside_inds = np.where(outside_mask)[0]
        cut_inds = np.where(~(inside_mask | outside_mask))[0]

        for eid in inside_inds: self.elements_list[eid].tag = 'inside'
        for eid in outside_inds: self.elements_list[eid].tag = 'outside'
        for eid in cut_inds: self.elements_list[eid].tag = 'cut'
        
        return inside_inds, outside_inds, cut_inds

    def classify_elements_multi(self, level_sets, tol=1e-12):
        """Classifies elements against multiple level sets."""
        return {idx: self.classify_elements(ls, tol) for idx, ls in enumerate(level_sets)}

    def classify_edges(self, level_set):
        """
        Classify edges as 'interface' or 'ghost' based on element tags.
        """
        phi_nodes = level_set.evaluate_on_nodes(self)
        for edge in self.edges_list:
            # Reset tag to avoid state from previous classifications
            edge.tag = ''

            # --- Primary classification for INTERIOR edges based on element tags ---
            if edge.right is not None:
                left_tag = self.elements_list[edge.left].tag
                right_tag = self.elements_list[edge.right].tag
                tags = {left_tag, right_tag}

                # An edge between two 'cut' elements is a 'ghost' edge.
                if tags == {'cut'}:
                    edge.tag = 'ghost'
                # An edge between a 'cut' element and a non-cut one is an 'interface'.
                elif 'cut' in tags and len(tags) > 1:
                    edge.tag = 'interface'
                # An edge between an 'inside' and 'outside' element is an 'interface'.
                elif tags == {'inside', 'outside'}:
                    edge.tag = 'interface'
            
            # --- Secondary check for any edge whose nodes cross the level set ---
            # The nodal crossing is the strongest indicator of the interface.
            # CRITICAL FIX: This must NOT override a 'ghost' tag.
            if edge.tag != 'ghost' and phi_nodes[edge.nodes[0]] * phi_nodes[edge.nodes[1]] < 0:
                edge.tag = 'interface'


    # --- Public API ---
    def element_char_length(self, elem_id):
        if elem_id is None:
            return 0.0
        return np.sqrt(self.areas()[elem_id])
    def neighbors(self) -> List[int]:
        return self._neighbors

    def edge(self, edge_id: int) -> 'Edge':
        """Return the Edge object corresponding to a global `edge_id`."""
        if not 0 <= edge_id < len(self.edges_list):
            raise IndexError(f"Edge ID {edge_id} out of range.")
        return self.edges_list[edge_id]

    def tag_boundary_edges(self, tag_functions: Dict[str, Callable[[float, float], bool]]):
        """Applies tags to boundary edges based on their midpoint location."""
        for edge in self.edges_list:
            if edge.right is None:
                midpoint = self.nodes_x_y_pos[list(edge.nodes)].mean(axis=0)
                for tag_name, func in tag_functions.items():
                    if func(midpoint[0], midpoint[1]):
                        edge.tag = tag_name
                        break

    def areas(self) -> np.ndarray:
        """Calculates the geometric area of each element."""
        element_areas = np.zeros(len(self.elements_list))
        for elem in self.elements_list:
            corner_coords = self.nodes_x_y_pos[list(elem.corner_nodes)]
            if self.element_type == 'tri':
                v0, v1, v2 = corner_coords[0], corner_coords[1], corner_coords[2]
                element_areas[elem.id] = 0.5 * np.abs(np.cross(v1 - v0, v2 - v0))
            elif self.element_type == 'quad':
                x, y = corner_coords[:, 0], corner_coords[:, 1]
                element_areas[elem.id] = 0.5 * np.abs(np.dot(x, np.roll(y, -1)) - np.dot(y, np.roll(x, -1)))
        return element_areas

    def __repr__(self):
        return (f"<Mesh n_nodes={len(self.nodes_list)}, "
                f"n_elems={len(self.elements_list)}, "
                f"n_edges={len(self.edges_list)}, "
                f"elem_type='{self.element_type}', "
                f"poly_order={self.poly_order}>")
